# Comic Box 📦 — Fire TV APK build (v0.3 prototype)

Fire TV / Android TV only. This app is a standalone comic library, not a movie player or Nuvio add-on.

**What this prototype actually does**
- Native comic-cover grid with 12 curated entries and a title filter.
- A six-page original illustrated reader test inside the APK. Click **Test Native Reader**, use Fire TV remote LEFT/RIGHT. No video format.
- Open comic sites in the built-in browser, keep reading position by URL, save series and page bookmarks.
- Site issue lists and online pages are rendered by each website's own reader, not by a native extractor. Site compatibility on Fire TV is unverified.
- Site metadata for the complete catalog, native reader extraction, and cross-site live search are NOT implemented.

**To compile without a PC, from your phone**
1. Create a new PUBLIC GitHub repo named `comic-box-firetv` (can be private if your plan has Actions minutes).
2. Upload **Comic_Box_FireTV_Project.zip** as one unchanged file at repository root.
3. In GitHub select Add file → Create new file. Type EXACTLY `.github/workflows/build.yml` as the filename, then paste the contents of **Comic_Box_FireTV_build.yml** and commit it.
4. Open repository → Actions → **Build Comic Box Fire TV APK** → Run workflow (or a push triggers automatically).
5. Open the successful run → Artifacts → Comic-Box-FireTV-APK → download its ZIP, extract `app-debug.apk`.
6. Install `app-debug.apk` on your Fire TV using an Android sideload method (for example Downloader or ADB). Android may ask to allow installs from unknown sources.
7. First test **Test Native Reader** on the home screen, then Batman → BatCave site to test internet reading.

**Unverified:** The APK has not yet been compiled, signed, or installed in an emulator/device. GitHub builds a standard debug-signed APK, which is suitable for your first test but not a production release. Do not install if CI reports an error.

**Why not one ZIP to GitHub?** GitHub does not automatically unpack source ZIPs. We use the source ZIP plus one workflow file to do that within the build job; this is convenient on Android phones.

If the build fails, copy the red error from the GitHub Actions step and send it back to ChatGPT to repair.
